
       
        <div id="fullWidthContainer">
            <div id="all">
                <script type="text/javascript">
                    var ajaxUrl = 'wall.php';
                </script>
                <?php require_once 'wall/' . $view . '.php'; ?>

            </div>

        </div>
        <div class="wallEntries">

        </div>
        <div id="picture">
            <h3>Use the form below to add the photo</h3>
            <div class="one-photo">
                <input type="file" name="photos[]" />
                <div class="preview"></div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="wallEntries">

        </div>
        <div id="picture">
            <h3>Use the form below to add the photo</h3>
            <div class="one-photo">
                <input type="file" name="photos[]" />
                <div class="preview"></div>
            </div>
            <div class="clear"></div>
        </div>

