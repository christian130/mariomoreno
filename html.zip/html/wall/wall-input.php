<div id="tabs">
    <ul>
        <li><a href="#status">Status</a></li>
        <li><a href="#picture">Pictures</a></li>
    </ul>
    <div id="status">
        <textarea name="status" ></textarea>
        <div id="link_info"></div>
        <input type="submit" name="add_status" value="Add" />
    </div>
    <div id="picture">
        <h3>Use the form below to add the photo</h3>
        <div class="one-photo">
            <input type="file" name="photos[]" />
            <div class="preview"></div>
        </div>
        <div class="clear"></div>
    </div>
</div>

