<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>:WHATSDADILLY:</title>
<link rel="stylesheet" href="css/reset-min.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>

<body>
<div id="topblack">
	<div class="topinner">
     <div id="logo"><a href=""><img src="images/logo.png" alt="WHATSDADILLY" /></a></div>
     <span class="amember2"><a href="index.php">Log In</a></span>
     <span class="amember">Already a WDD Member?</span>
     
    	</div>
	</div>
<div id="logincontainer">
	<div class="logleft">
    	<h1>Find out what’s happening, right now,</h1>
		<h2>with all your social netwroks, all-in-on.</h2>
        <div id="sicons">
	<ul>
   <li><a href="#">Facebook</a></li> 
   <li><a href="#">Tweeter</a></li>
   <li><a href="#">LIn</a></li>
   <li><a href="#">Gplus</a></li>
   <li><a href="#">Facebook</a></li> 
   <li><a href="#">Tweeter</a></li>
   <li><a href="#">LIn</a></li>
   <li class="nomargR"><a href="#">Gplus</a></li>
    </ul>
	</div>
    <div class="orngtxt orngmarg">Mix all your social networks in one</div>
    <div class="orngtxt">Share what’s new in your life on your Timeline</div>
    <div class="orngtxt">See all updates from friends in one News Feed</div>
			    			</div>
                            
   <div class="signbgwrap">
   	<div class="signbg">
    	<h3>- Reset Username</h3>
        <input type="text"  value="" class="locinput2" placeholder="Enter your email id">
        <input type="submit" value="Reset Username" class="btn_signup" />   
         </div>
   </div> 
  <div class="logfoot">
  	<div class="fmenu">
      <ul>
   <li><a href="#">About</a></li> 
   <li><a href="#">Help</a></li> 
   <li><a href="#">Blog</a></li> 
   <li><a href="#">Status</a></li> 
   <li><a href="#">Terms</a></li> 
   <li><a href="#">Privacy</a></li> 
   <li><a href="#">Advertisers</a></li> 
   <li><a href="#">Businesses</a></li>
   <li><a href="#">Directory</a></li>   
      </ul>
    	</div>
  <span class="toimg"><img src="images/tobg.png" alt="" /></span>   
  <p>Copyright 2013 whatsdadilly. All Rights Reserved.</p>   
  				</div>                                      
	</div>    
</body>
</html>
