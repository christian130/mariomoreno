<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>:WHATSDADILLY:</title>
        <link rel="stylesheet" href="css/reset-min.css" type="text/css" />
        <link rel="stylesheet" href="css/style.css" type="text/css" />
        <link rel="stylesheet" href="css/wall.css" type="text/css" />
        <link rel="stylesheet" href="css/jquery.fancybox.css" type="text/css" />
        <script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
        <script type="text/javascript" src="js/jquery.validate.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>

        <link href='css/nprogress.css' rel='stylesheet' />
        <script type="text/javascript" src='js/nprogress.js'></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
            <link type="text/css" rel="stylesheet" href="css/tab/responsive-tabs.css" />
            <link type="text/css" rel="stylesheet" href="css/tab/style.css" />
            <script type="text/javascript" src="js/jquery-1.9.1.js"></script>
            <script type="text/javascript" src="js/jquery.min.js"></script>
            <script type="text/javascript" src="js/jquery.colorbox.js"></script>
            <link rel="stylesheet" href="css/colorbox.css" type="text/css" />
            <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

                <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
                <link href="css/registration-process1.css" rel="stylesheet">

                    <script type="text/javascript">
                        function submitForm() {
                            console.log("submit event");
                            var fd = new FormData(document.getElementById("upload_photos"));
                            fd.append("label", "WEBUPLOAD");
                            $.ajax({
                                url: "wdd_ajaxupload.php",
                                type: "POST",
                                data: fd,
                                enctype: 'multipart/form-data',
                                processData: false,  // tell jQuery not to process the data
                                contentType: false   // tell jQuery not to set contentType
                            }).done(function( data ) {
                                $(".wallEntries").prepend(data);
                                $(".one-photo").remove();
                                // console.log("PHP Output:");
                                // $( ".one-photo" ).empty();
                                console.log( data );
                            });
                            return false;
                        }
            
                    </script>
                <!--<script type="text/javascript">
                        $(document).ready(function() {
                            $(".wall_popup").colorbox({
                                fixed:true,
                                rel:'wall_popup',

                                scrolling:false,

                                onComplete: function() {
                                                  var window_height = $(window).height();
                                    var colorbox_height = $('#colorbox').height();
                                    var top_position = 0;

                                    if(window_height > colorbox_height) {
                                        top_position = (window_height - colorbox_height) / 2;
                                    }

                                       $('#colorbox').css({'top':top_position, 'position':'fixed'});
                                }
                            });
                            $(document).bind('cbox_open', function() {
                                $('html').css({ overflow: 'hidden' });
                            }).bind('cbox_closed', function() {
                                $('html').css({ overflow: '' });
                            });
                        });
                    </script> -->
                    <?php
                    require 'instagramoauth/instagram.class.php';

// initialize class
                    $instagram = new Instagram(array(
                                'apiKey' => '5b610f1450884e93b4511629141a74af',
                                'apiSecret' => 'c86de353c84248f7a80d5e4bc8038aaf',
                                'apiCallback' => 'http://localhost/projects/whatsdadilly/instagram_add.php' // must point to success.php
                            ));

// create login URL
                    $loginUrl = $instagram->getLoginUrl();
                    ?>
                    <script type="text/javascript">
                        $(document).ready(function() {
                            $( "#dialog" ).dialog(
                            {
                                title: "Add Social Networks",
                                width: "40%",
                                modal: true
                            });
                            //                        $.ajax({
                            //                            url: 'test.ini',
                            //                            dataType: 'json',
                            //                            data: "",
                            //                            success: function(doc) {
                            //                                //$( "#dialog").html(doc);
                            //                                $( "#dialog" ).dialog(
                            //                                {
                            //                                    title: "My Dialog Title",
                            //                                    modal: true
                            //                                });
                            //                            }
                            //                        });

                            
                        
                            $(".wall_popup").colorbox({
                                fixed:true,
                                scrolling:false,
                                rel:'wall_popup'});
                            $(document).bind('cbox_open', function() {
                                $('html').css({ overflow: '' });
                            }).bind('cbox_closed', function() {
                                $('html').css({ overflow: '' });
                            });
      
                        });

                        /*function waitForMsg(){
                                 /* This requests the url "msgsrv.php"
                     When it complete (or errors)*/
                        //var firstid =  $('.crispbxmain').attr("data");
                        //  $.ajax({
                        //   type: "POST",
                        //    url: "msgsrv.php?post_id="+firstid,
                        //   async: true, /* If set to non-async, browser shows page as "Loading.."*/
                        //   cache: false,
                        //   timeout:50000, /* Timeout in ms */

                        //  success: function(data){ /* called when request to barge.php completes */
                        //     $(".wallEntries").prepend(data); /* Add response to a .msg div (with the "new" class)*/
                        //     setTimeout(
                        //     waitForMsg, /* Request next message */
                        //     1000 /* ..after 1 seconds */
                        //  );
                        //  },
                        //  error: function(XMLHttpRequest, textStatus, errorThrown){
                          
                        //     setTimeout(
                        //     waitForMsg, /* Try again after.. */
                        //  15000); /* milliseconds (15seconds) */
                        //  }
                        // });
                        // };*/
                    </script>




                    <style>
                        /*                    .ui-widget-overlay.custom-overlay
                                            {
                                                background-color: black !important;
                                                background-image: none;
                                                opacity: 0.9;
                                                z-index: 1040;
                                            }*/
                        .peopwrap img{

                            width:50px;
                            height:45px;
                        }

                        #topblack
                        {
                            top:0px;
                        }

                        body
                        {
                            background:#fff !important;
                            padding-top: 0px !important;
                        }
                        td
                        {
                            color:#333 !important;
                        }

                        .wrapper-dropdown-3
                        {
                            width:100px !important;
                        }
                        .plusign
                        {
                            //border-top-right-radius: -10px !important;
                            //border-top-left-radius: -25px !important;
                            padding: 3px;
                            background:none !important;
                            color:#333 !important;
                            border-radius: 20% !important;
                            box-shadow:none !important;
                            margin-left: 10px !important;
                            margin-top: 10px !important;
                        }
                        .plusign:hover
                        {
                            background: #00c7df;
                            color:#fff;

                        }

                    </style>
                    <script type="text/javascript">
                        function loadComments(){
                            var lastcommentid = $("#lastcommentID").val();

                            $.getJSON('commentlist.php?commentid='+lastcommentid, function(data) {
                                if(data != null){
                                    // alert(data.length);
                                    // alert("Data0Title: " + );
                                    $("#lastcommentID").val(data[0].cmt_id);
                                    $(".wallEntries").find("#comment_"+data[0].dev_id).prepend(data[0].comment_block);
                                    $.av.pop({
                                        title: 'Comment',
                                        expire: 2000,
                                        message: data[0].comment_block
                                    });
                                }
                            });
                        }
                        //var comments = setInterval(loadComments, 10000);
                    </script>
                    </head>
<?php
                    $session = new Session();
                    if ($session->getSession('userid') != null) {
?>
                                                                                                                                    <!--<script type="text/javascript" src="js/updater.js"></script>
                                                                                                                                             <script type="text/javascript" src="js/updater_remove.js"></script>-->
<?php
                    }
?>
                    <body  class="nobg">
                        <div id="dialog" title="Basic dialog" style="display:none;">
                            <table width="100%" border="0" class="">
                                <tr>
                                    <td> <img src="rgimages/facebook.png"></td>
                                    <td>Connect your Facebook account</td>
                                </tr>
                                <tr>
                                    <td> <img src="rgimages/twtr.png"></td>
                                    <td>
                                        Connect your Twitter account
<?php
                    foreach ($accounts as $acc) {
                        if ($acc['networkname'] == 'twitter') {
?>
                                        <a href="#" id="<?php echo $acc["token_id"]; ?>"  class="delbutton" style="color:#555;float:right;">@<?php echo $acc['screen_name']; ?> &nbsp;<i class="fa fa-times"></i></a>
<?php }
                                } ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="rgimages/pinterest.png"></td>
                                    <td>Connect your Pinterest account</td>
                                </tr>
                                <tr style="border-bottom:none;">
                                    <td> <img src="rgimages/instagram-icon.png"></td>
                                    <td>
                                        <a class="login" href="<?php echo $loginUrl ?>"><img src="rgimages/insta_preview.png"></a>
                                        <?php
                    foreach ($accounts as $acc) {
                        if ($acc['networkname'] == 'instagram') {
?>
                                        <a href="#" id="<?php echo $acc["token_id"]; ?>"  class="delbutton" style="color:#555;float:right;">@<?php echo $acc['screen_name']; ?> &nbsp;<i class="fa fa-times"></i></a>
<?php }
                                } ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        </div>
                        <div class="main_content">
                            <script type="text/javascript">
                                var ajaxUrl = 'wall.php';
                            </script>
<?php include 'header.php'; ?>
                            <div class="midwht">
                                <div class="homlft">
<?php include 'profilepic.php'; ?>
                                                <div class="profilelinks">
                                                    <ul class="mailcontent">

                                                        <li><div style="height:30px; width:30px;float:left;"><i class="fa fa-camera" style="color:#fff;margin-top:3px;"></i> </div><a href="album.php" style="color:#fff !important;">Photos</a></li>

                                                    </ul>
                                                </div>
                                            </div>

                                            <input type="hidden" name="social_menu" id="social_menu" value="wdd" />


                                            <div class="hommid" >

                                                <div id="horizontalTab">
                                                    <ul class="mytabs">
                                                        <li><a href="home.php" style="padding-top:0px !important;top:0px;"><span style="font-family: Impact, Haettenschweiler;font-size:14px;font-weight:normal;"> ? |</span> Whiteboard</a></li>
                                                        <li><a href="insta_feeds.php">Instagram</a></li>
                                                        <li><a href="twitter_feeds.php">Twitter</a></li>
                                                       <!--  <li><a href="#tab-3"><i class="fa fa-facebook"><i class="fa fa-twitter" style="font-size:14px;"></i>&nbsp;| Whiteboard</i>&nbsp;</a></li>
                                                        <li><a href="#tab-4"><i class="fa fa-linkedin"></i>&nbsp;</a></li>  -->
                                                        <li class="plusign"><i class="fa fa-plus " ></i></li>


                                                    </ul>



                                                    <div id="tabs-container">
                                                        <script type="text/javascript" src="js/wall.js"></script>

                                                        <div style="float: right;margin-top: -30px;"> <?php include 'socialmenu.php'; ?></div>
                                                <form action="wdd_ajaxupload.php" id="upload_photos" method="post" onsubmit="return submitForm();">
                                                    <textarea name="status" class="grybord">Whats in your head?</textarea>
                                                    <div id="link_info"></div>
                                                    <div class="clear"></div>
                                                    <div id="picture">
                                                        <h3>Use the form below to add photos.</h3>
                                                        <div class="one-photo">
                                                            <input class="fileUpload" type="file" name="photo_0" />
                                                            <div class="removePhoto">remove</div>
                                                            <div class="preview"></div>
                                                        </div>
                                                        <div class="clear"></div>
                                                    </div>
                                                    <div class="dgry">
                                                        <div class="picon"><a href="#"> <img src="images/photoicon.png" alt="" /></a> </div>
                                                        <input type="submit" class="postbutton" value="post" />
                                                    </div>
                                                </form>

                                                <div class="bluebg">Whiteboard</div>
                                                <div class="tabgray" style="display:none;">
                                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                        <tr valign="middle">
                                                            <td class="homtit" width="55" height="25"></td>
                                                            <td class="homtit" width="40"></td>
                                                            <td class="homtit" width="62"></td>
                                                            <td class="homtit" width="62"></td>
                                                            <td class="homtit" width="52"></td>
                                                            <td class="homtit" width="52"></td>
                                                            <td>&nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <div class="postbg">6 new posts</div>
                                                <div class="peoplebx">
                                                    <!--div class="jessicatxt">Jessica is now friends with Karla M. and 7 other people</div-->
                                                    <!--div class="peopwrap"> <a href="#"><img src="images/fim1.jpg" alt="" /> <img src="images/fim2.jpg" alt="" /> <img src="images/fim3.jpg" alt="" /> <img src="images/fim4.jpg" alt="" /> <img src="images/fim5.jpg" alt="" /> <img src="images/fim6.jpg" alt="" /> <img src="images/fim7.jpg" alt="" /> <img src="images/fim8.jpg" alt="" /></a> </div-->
                                                </div>
                                                <!--<div id="postedComments" style="display:none;"></div>-->


                                                <div class="wallEntries" id="getting_wdd_wall">
                                                    <input type="hidden" name="lastcommentID" id="lastcommentID" value="<?php echo $last_comment['id']; ?>" />
<?php
                                        $postids = 0;
//echo '<pre>';
//print_r($entries);
                                        foreach ($entries as $entry) {
                                            //echo $entry['id'];
                                            $userdetails = WallModel::getUserDetails($entityManager, $entry['user_id']);
?>

                                                <div class="crispbx crispbxmain" id="wall<?php echo $entry['id']; ?>" data="<?php echo $entry['id']; ?>" data-count="<?php echo $postids; ?>">
                                                    <img src="uploads/<?php echo $userdetails[0]['profile_pic']; ?>" alt="" width="40px;" height="40px;" style="padding:5px;border-radius:px; "/>

                                                    <div class="crispcont">
                                                        <h2><?php echo $userdetails[0]['firstname'] ?> <?php echo $userdetails[0]['lastname'] ?></h2>
                                                        <p class="status-text"><?php echo Functions::addLink($entry['text']) ?></p>
<?php if (strlen($entry['link']) > 0) { ?>
                                                            <div class="link_container">
<?php if (strlen($entry['link_photo']) > 0): ?>
                                                            <img src="<?php echo $entry['link_photo'] ?>" alt=""/>
<?php endif ?>
                                                            <div class="clear"></div>
                                                            <p><a target="_blank" href="<?php echo $entry['link'] ?>"><?php echo $entry['link_title'] ?></a></p>
                                                            <p><?php echo $entry['link_description'] ?></p>
                                                            <div class="clear"></div>
                                                        </div>
<?php } ?>

<?php if (!empty($entry['photos'])) {
?>
                                                        <div class="crispbx">
                                                            <div class="crispcont">
                                                                <p><?php echo count($entry['photos']) ?> photos uploaded</p>
<?php if (count($entry['photos']) > 1) { ?>
                                                                    <div class="upimgwrap">

                                                                        <div class="big-photo-container">
                                                                            <a class="wall_popup group1" href="wall_popup.php?wall_id=<?php echo $entry['id']; ?>&photoid=<?php echo $entry['photos'][0]['id']; ?>&postion=0">
                                                                            <img src="uploads/<?php echo $entry['photos'][0]['file'] ?>" alt=""  class="upbigimg"/>
                                                                        </a>
                                                                    </div>
                                                                    <div class="upsmimg">
<?php
                                                            $postion = 1;
                                                            foreach ($entry['photos'] as $key => $photo) {
                                                                if ($key == 0)
                                                                    continue;
?>
                                                                        <div class="small-photo-container">
                                                                            <a class="wall_popup group1" href="wall_popup.php?wall_id=<?php echo $entry['id']; ?>&photoid=<?php echo $photo['id']; ?>&postion=<?php echo $postion; ?>">
                                                                                <img src="uploads/<?php echo $photo['file'] ?>" alt="" />
                                                                            </a>
                                                                        </div>
<?php $postion++;
                                                                    } ?>
                                                                    </div>
                                                                </div>
<?php } else { ?>
                                                                <div class="upimgwrap1">

                                                                    <div class="big-photo-container1">
                                                                        <a class="wall_popup group1" href="wall_popup.php?wall_id=<?php echo $entry['id']; ?>&photoid=<?php echo $entry['photos'][0]['id']; ?>&postion=0">
                                                                                <img src="uploads/<?php echo $entry['photos'][0]['file'] ?>" alt=""  class="upbigimg"/>
                                                                            </a>
                                                                        </div>
                                                                    </div>
<?php } ?>
                                                            </div>
                                                        </div>
<?php } ?>
                                                        <div class="likemenu">
                                                            <ul>
                                                                <li><a href="#">Like</a></li>
                                                                <li><a class="add-comment-link" rel="<?php echo $entry['id'] ?>" href="#">Comment</a></li>
                                                                    <li><a href="#">Share</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>

                                                        <div class="clear"></div>
                                                        <div class="commentmain" >
                                                            <div class="comment-section" data="<?php echo $entry['id']; ?>" id="comment_<?php echo $entry['id'] ?>" style="display:none;">
<?php //echo '<pre>'; print_r($entry['comments']);  ?>
                                                            <?php
                                                            foreach ($entry['comments'] as $comment):
                                                                $cuserdetails = WallModel::getUserDetails($entityManager, $comment['author_id']);
                                                                //echo '<pre>'; print_r($cuserdetails);
                                                            ?>
                                                                <div class="comment-block">
                                                                    <table border="0">
                                                                        <tr>
                                                                            <td style="width:5%" valign="top">

                                                                                <img src="uploads/<?php echo $cuserdetails[0]['profile_pic']; ?>" alt="<?php echo $comment['firstname'] ?> <?php echo $comment['lastname'] ?>" width="32px;" height="32px;" style="border-radius:px;"></td>
                                                                            <td valign="top"><div class="comment-content" style="color:#999;margin-left:0px !important;">
                                                                              <!--  <h2 ><?php echo $comment['firstname'] ?> <?php echo $comment['lastname'] ?></h2>
                                                                                <p style="color:#fff;"><?php echo Functions::addLink($comment['text']) ?></p></br></br>
                                                                                <p style="margin-top:-15px;color:#ccc;"><?php echo date('m/d/Y H:i:s', strtotime($comment['date'])) ?></p> -->

                                                                                    <p style="color:#fff;"><b style="color:#ffa96e;"><?php echo $comment['firstname'] ?> <?php echo $comment['lastname'] ?></b>&nbsp;
<?php echo Functions::addLink($comment['text']) ?></br>
                                                                                        <span style="color:#ccc !important;"><?php echo date('m/d/Y H:i:s', strtotime($comment['date'])) ?></span></p>
                                                                            </div></td> </tr></table>
                                                                <div class="clear"></div>
                                                            </div>
<?php endforeach ?>
                                                        </div>
                                                        <div class="add-comment" rel="<?php echo $entry['id'] ?>">
                                                                <form rel="<?php echo $entry['id'] ?>" id="commform_<?php echo $entry['id'] ?>" action="" method="post" enctype="multipart/form-data">
                                                                    <table width="100%">
                                                                        <tr>
                                                                            <td width="10%"><img src="uploads/<?php echo $session->getSession("profile_pic"); ?>" alt="" width="32px;" height="32px;" style="border-radius:px;margin-left: 5px; "/></td>
                                                                            <td width="90%"><textarea placeholder="Start typing your comment here" class="grybord" id="wallcomment" name="comment"></textarea></td>
                                                                        </tr>
                                                                    </table>
                                                                    <div style="float: right;
                                                                         margin-top: -22px;
                                                                         position: relative;
                                                                         margin-right: 15px;">
                                                                        <i class="fa fa-camera fa-lg" style="float: right;color:#999999;
                                                                           cursor: pointer;"></i>
                                                                        <input for="file-input" rel="<?php echo $entry['id'] ?>" type="file" name="photo" style="opacity: 0;
                                                                               float: right;   filter: alpha(opacity=0);margin-right: -18px;margin-top: -5px;width: 23px;"/> </div>
                                                                    <input name="post_id" type="hidden" value="<?php echo $entry['id'] ?>" />
                                                                    <input type="button" class="postbutton-comments" id="<?php echo $entry['id'] ?>" value="post" />
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>


<?php
                                                                $postids++;
                                                            }
?>

                                                            <div id="loadorders"></div>
                                                            <div id="loadMoreComments" style="display:none;" ></div>
                                                                                                                  <!--<iframe id="wall-iframe" scrolling="no" frameborder="0" src="wall-itself.php"></iframe>-->
                                                        </div></div>


                                                </div>
                                            </div>
                                            <div class="friendright">
<?php $result = $messages->getFriends($entityManager, $session->getSession("userid"), 8); ?>
                                                <a href="friend_list.php" ><h3 class="">Friends(<font class="totalfriends"><?php echo $messages->getNumber(true); ?></font>)</h3></a>
                                                            <div class="friendwrap">
<?php echo $result; ?>
                                                            </div>
                                                        </div>
                                                        <div class="logfoot">
                                                            <div class="fmenu">
                                                                <ul>
                                                                    <li><a href="#">About</a></li>
                                                                    <li><a href="#">Help</a></li>
                                                                    <li><a href="#">Blog</a></li>
                                                                    <li><a href="#">Status</a></li>
                                                                    <li><a href="#">Terms</a></li>
                                                                    <li><a href="#">Privacy</a></li>
                                                                    <li><a href="#">Advertisers</a></li>
                                                                    <li><a href="#">Businesses</a></li>
                                                                    <li><a href="#">Directory</a></li>
                                                                </ul>
                                                            </div>
                                                            <span class="toimg"><img src="images/tobg.png" alt="" /></span>
                                                            <p>Copyright 2013 whatsdadilly. All Rights Reserved.</p>
                                                        </div>
                                                        <p id="back-top">
                                                            <a href="#top"><span></span>Back to Top</a>
                                                            <style>
                                                                #close_notific img{
                                                                    height: 20px;
                                                                    width: 20px;
                                                                    position: absolute;
                                                                    right: 1px;
                                                                    top: 1px;
                                                                }
                                                            </style> </p>



                                                    </div>
                                            </body>
                                            </html>


                                            <script>
<?php if ($_GET['msg'] == 'success') { ?>
                        alert("Account added successfully!!!");
                        opener.location.reload();
                        window.close();
                        $('body').show();
                        $('.version').text(NProgress.version);
                        NProgress.start();
                        setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000);
<?php } else if ($_GET['msg'] == 'error') { ?>
                        alert("Oops Already acount availablle!!!");
                        opener.location.reload();
                        window.close();
                        $('body').show();
                        $('.version').text(NProgress.version);
                        NProgress.start();
                        setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000);
<?php } ?>
                    </script>
                    <script>
                        $('body').show();
                        $('.version').text(NProgress.version);
                        NProgress.start();
                        setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000);

                    </script>
                    <script>
                        $('body').show();
                        $('.version').text(NProgress.version);
                        NProgress.start();
                        setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000);

                    </script>


                    <!-- jQuery with fallback to the 1.* for old IE -->
                    <!--[if lt IE 9]>
                        <script src="js/tab1/jquery-1.11.0.min.js"></script>
                    <![endif]-->
                    <!--[if gte IE 9]><!-->
                    <script src="js/tab1/jquery-2.1.0.min.js"></script>
                    <!--<![endif]-->

                    <!-- Responsive Tabs JS -->
                    <script src="js/tab/jquery.responsiveTabs.js" type="text/javascript"></script>

                    <script type="text/javascript">
                        //     $(document).ready(function() {
                        //        $("#inst_feeds").click(function(event){
                        //            $('body').show();
                        //            $('.version').text(NProgress.version);
                        //            NProgress.start();
                        //            $('#tabs-container').load('insta_feeds.php');
                        //            setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 1000);
                        //        });
                        //    });
    
                        var containerId = '#tabs-container';
                        var tabsId = '.mytabs';

                        $(document).ready(function(){
                            // Preload tab on page load
                            if($(tabsId + ' LI.current A').length > 0){
                                loadTab($(tabsId + ' LI.current A'));
                            }

                            $(tabsId + ' A').click(function(){
                                //$("").val();
          
                                if($(this).parent().hasClass('current')){ return false; }
                                if($(this).attr("href") == 'insta_feeds.php'){
                                    $("#social_menu").val("instagram");
                                    $('body').css('background-image', 'none');
                                    document.body.style.backgroundRepeat="repeat";
                                    document.body.style.height = "100%";
                                    $(tabsId + ' LI.current').removeClass('current');
                                    $(this).parent().addClass('current');

                                    loadTab($(this));
                                }else if($(this).attr("href") == 'twitter_feeds.php'){
                                    $("#social_menu").val("twitter");
                                    $(tabsId + ' LI.current').removeClass('current');
                                    $(this).parent().addClass('current');

                                    loadTab($(this));
                                } else if($(this).attr("href") == 'home.php'){
                
                                    $("#social_menu").val("wdd");
                                    $(tabsId + ' LI.current').removeClass('current');
                                    $(this).parent().addClass('current');

                                    loadWddTab($(this));
                                }
            
                                $('body').show();
                                $('.version').text(NProgress.version);
                                NProgress.start();
            
                                return false;
                            });
                        });

                        function loadTab(tabObj){
                            //        if(!tabObj || !tabObj.length){ return; }
                            //        $(containerId).addClass('loading');
                            //        $(containerId).fadeOut('fast');

                            $(containerId).load(tabObj.attr('href'), function(){
                                //            $(containerId).removeClass('loading');
                                //            $(containerId).fadeIn('fast');
                                setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 500);
                            });
                        }
                        function loadWddTab(tabObj){
                            if(!tabObj || !tabObj.length){ return; }
                            $(containerId).addClass('loading');
                            $(containerId).fadeOut('fast');

                            $(containerId).load('home.php #tabs-container', function(){
                                $(containerId).removeClass('loading');
                                $(containerId).fadeIn('fast');
                                setTimeout(function() { NProgress.done(); $('.fade').removeClass('out'); }, 500);
                                $(".wallEntries").append( "<p id='last'></p>" );
                            });
                        }
                    </script>

