<style>
	.ba_info td {
      width: 415px;	
         }
	.ba_info {
                //border-collapse:separate;
                border-spacing:16px 10px !important;
      width: 430px;	
      margin:5px;
    }
.sqicon
{
width: 24px;
height: 24px;
background: #333;
border-radius: 3px;
margin-right: 2px;
float:left;
}


</style>
 <div style="border-bottom:1px solid #d3d6db;width:100%;height:23px;"><h2 style="font-size:14px;font-weight:bold;color:#333;float:left;margin:3px;" >Basic Information</h2>
                                    <?php if (isset($_GET['profileid']) && (base64_decode($_GET['profileid']) != $session->getSession("userid"))) {
                                    ?>
                                    <?php } else {
                                    ?>
                                        <a style="float:right;margin:3px;" href="javascript:void(0)" onclick="basicinfos();">Edit</a>
                                    <?php } ?>
                                </div>
 <!-- <div style="float:left;margin-left:15px;"><b style="color:black;">Basic Info</b></div>-->
							   <div style="float:left;">
								<form name="basicinfo" id="basicinfo" class="basicinfo" action="" method="post">
                                    <input type="hidden" name="segment" id="segment" value="basicinfo" />
                                    <div style="padding-top:0px;">
                                        <table class="ba_info">
<tr>
<td>
                                                    <div class="sqicon"><i class="fa fa-calendar" style="color:#fff;margin:4px;"></i> <!-- <img src="images/birthday.png" style="width:18px;" /> --></div>
													<div style="float:left;margin-left:0px;color:#666;">Birthday:</td></div>
                                                </td>
                                                <td>
                                                   <input type="text" name="dob" id="dob" value="<?php echo ucfirst(Date($user_det[0]['dob']->date)); ?>" class="proedits" readonly/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                   <div class="sqicon"> <!-- <img src="images/gender.png" style="width:18px;" /> --> 



<i class="fa fa-users" style="color:#fff;margin:4px;"></i> </div>
<div style="float:left;margin-left:0px;color:#666;">Gender:</div>
                                                </td>
                                                <td>
                                                    <?php echo ucfirst($user_det[0]['gender']); ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                  <div class="sqicon"> <i class="fa fa-home" style="color:#fff;margin:4px;"></i>  <!--<img src="images/home.png" style="width:18px;" /> --></div> 
												   <div style="float:left;margin-left:0px;color:#666;">Lives in:</div>
                                                </td>
                                                <td>
                                                    <input style=";" type="text" name="current_city" id="current_city" value="<?php echo ucfirst($current_city[0]['city']); ?> <?php echo ucfirst($current_city[0]['country']); ?>" class="proedits" readonly/>
                                                    <input type="hidden" name="current_city_id" id="current_city_id" value="<?php echo $user_det[0]['current_city']; ?>" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                  <div class="sqicon"><i class="fa fa-map-marker" style="color:#fff;margin:4px;padding-left: 3px;"></i> <!-- <img src="images/location.png" style="width:18px;" /> --></div>
											<div style="float:left;margin-left:0px;color:#666;">Home:</div>	 
                                                </td>
                                                <td>
                                                    <input sty le=";"type="text" name="home_city" id="home_city" value="<?php echo ucfirst($home_city[0]['city']); ?> <?php echo ucfirst($home_city[0]['country']); ?>" class="proedits" readonly/>
                                                    <input type="hidden" name="home_city_id" id="home_city_id" value="<?php echo $user_det[0]['home_city']; ?>" />
                                                </td>
                                            </tr>
                                            <tr><?php $inter = $user_det[0]['interested']; ?>
                                                <td>
                                                   <div class="sqicon"><i class="fa fa-eye" style="color:#fff;margin:4px;"></i> <!-- <img src="images/int.png" style="width:18px;" /> --> </div>
<div style="float:left;margin-left:0px;color:#666;">Interested In:</div>													   
                                                </td>
                                                <td> 
                                                    <select style=";margin-left:px;padding:0px;" name="interested" id="dropdown" class="dropdown" readonly>
                                                        <option>Select</option>
                                                        <option value="Male" <?php echo $inter == 'Male' ? 'selected' : ''; ?>>Male</option>
                                                        <option value="Female" <?php echo $inter == 'Female' ? 'selected' : ''; ?>>Female</option>
                                                        <option value="Both" <?php echo $inter == 'Both' ? 'selected' : ''; ?>>Both</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                   <div class="sqicon"><i class="fa fa-heart" style="color:#fff;margin:4px;"></i> <!-- <img src="images/heart.png" style="width:18px;" /> --></div> 
												   <div style="float:left;margin-left:0px;color:#666;">Relationship:</div>
                                                </td>
                                                <td><?php $rel = $user_det[0]['relationship']; ?>
                                                    <select style=";margin-left:px;padding:0px;"  name="relationship" id="dropdown1" class="dropdown" readonly>
                                                        <option>Select</option>
                                                        <option value="Single" <?php echo $rel == 'Single' ? 'selected' : ''; ?>>Single</option>
                                                        <option value="Divorced" <?php echo $rel == 'Divorced' ? 'selected' : ''; ?>>Divorced</option>
                                                        <option value="Separated" <?php echo $rel == 'Separated' ? 'selected' : ''; ?>>Separated</option>
                                                        <option value="Married" <?php echo $rel == 'Married' ? 'selected' : ''; ?>>Married</option>
                                                        <option value="Open" <?php echo $rel == 'Open' ? 'selected' : ''; ?>>Open</option>
                                                        <option value="Widowed" <?php echo $rel == 'Widowed' ? 'selected' : ''; ?>>Widowed</option>
                                                        <option value="Common Law" <?php echo $rel == 'Common Law' ? 'selected' : ''; ?>>Common Law</option>
                                                        <option value="Dating" <?php echo $rel == 'Dating' ? 'selected' : ''; ?>>Dating</option>
                                                        <option value="Seeing Someone" <?php echo $rel == 'Seeing Someone' ? 'selected' : ''; ?>>Seeing Someone</option>
                                                        <option value="Engaged" <?php echo $rel == 'Engaged' ? 'selected' : ''; ?>>Engaged</option>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                   <div class="sqicon"> <i class="fa fa-male" style="color:#fff;margin:4px;padding-left: 3px;"></i> <!--<img src="images/politics.png" style="width:18px;" />  --></div>
 <div style="float:left;margin-left:0px;color:#666;">Political Views:</div>												   
                                                </td>
                                                <td>
                                                    <input style=";"  type="text" name="politicalview" id="politicalview" value="<?php echo ucfirst($user_det[0]['politicalview']); ?>" class="proedits" readonly/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                   <div class="sqicon"> <i class="fa fa-globe" style="color:#fff;margin:4px;padding-left: 2px;"></i>  <!--<img src="images/hands.png" style="width:18px;" /> --></div>
												 <div style="float:left;color:#666;">Religion:</div>		
                                                </td>
                                                <td>
                                                    <input style=";" type="text" name="religion" id="religion" value="<?php echo ucfirst($user_det[0]['religion']); ?>" class="proedits" readonly/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                   <div class="sqicon"><i class="fa fa-pencil-square-o" style="color:#fff;margin:4px;padding-left: 1px;"></i><!-- <img src="images/lang.png" style="width:18px;" /> --></div>
												    <div style="float:left;margin-left:0px;color:#666;">Language:</div>	
                                                </td>
                                                <td>
                                                    <input style=";" type="text" name="language" id="language" value="<?php echo ucfirst($user_det[0]['language']); ?>" class="proedits" readonly/>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="sqicon"> <i class="fa fa-paper-plane" style="color:#fff;margin:4px;"></i> <!--<img src="images/login.png" style="width:18px;" /> --></div>
													 <div style="float:left;margin-left:0px;color:#666;">Last login:</td></div>
                                                <td>
                                                    <?php echo ucfirst($user_det[0]['last_login']); ?>
                                                </td>
                                            </tr>
                                           
                                           <tr></tr>
 <tr style="display: none;" class="pro_button">
<td style="border-bottom:none !important;"></td>
                                                <td style="border-bottom:none !important;">
                                                                    <div style="float:right;margin-right:-20px;">

                                                    <input type="button" name="Cancel" value="Cancel" class="button" onclick="basiccancel()"/>
                                                  
 <input type="button" name="Save" value="Save" class="button" onclick="savebasicinfo()"/> </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </form>
							   </div>
                               