<div class="logfoot" style="text-align:center;">
    <div class="fmenu">
      <!--  <ul>
            <li><a href="#">About</a></li>
            <li><a href="#">Help</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Status</a></li>
            <li><a href="#">Terms</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="#">Advertisers</a></li>
            <li><a href="#">Businesses</a></li>
            <li><a href="#">Directory</a></li>
        </ul> -->
    </div>
<!--    <span class="toimg"><img src="images/tobg.png" alt="" /></span>-->
</br></br></br></br>
    <p style="width:100%;">Copyright 2014 whatsdadilly. All Rights Reserved.</p>
</div>