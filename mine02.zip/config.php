<?php
//Replace XXX with your twitter application variables.
define('CONSUMER_KEY', 'sHQDVwHE6N0A45QlR5Q');
define('CONSUMER_SECRET', 'IxG87DcyIYiQC3QyYEXt5zmhTvm2YbRp8XGF1ZwSIs');
define('OAUTH_CALLBACK', 'http://whatsdadilly.com/betaPhase/process.php');
define('IG_CONSUMER_KEY', '5b610f1450884e93b4511629141a74af');
define('IG_CONSUMER_SECRET', 'abebe7c0cd504e64ae885c85b18cd33f');
define('IG_OAUTH_CALLBACK', 'http://whatsdadilly.com/betaPhase/instagram_add.php');
?>