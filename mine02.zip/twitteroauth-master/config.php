<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'sHQDVwHE6N0A45QlR5Q');
define('CONSUMER_SECRET', 'IxG87DcyIYiQC3QyYEXt5zmhTvm2YbRp8XGF1ZwSIs');
define('OAUTH_CALLBACK', 'http://whatsdadilly.com/beta/twitteroauth-master/callback.php');
