<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>:WHATSDADILLY:</title>

    </head>
    <body>
        <div style="text-align: center;">
            <div style="box-sizing: border-box; display: inline-block; width: auto; max-width: 480px; background-color: #FFFFFF; border: 2px solid #0361A8; border-radius: 5px; box-shadow: 0px 0px 8px #0361A8; margin: 50px auto auto;">
                <div style="background: #0361A8; border-radius: 2px 2px 0px 0px; padding: 15px;"><span style="font-family: verdana,arial; color: #D4D4D4; font-size: 1.00em; font-weight:bold;">Enter your login and password</span></div>
                <div style="padding: 15px">
                    <style type="text/css" scoped>
                        td { text-align:left; font-family: verdana,arial; color: #064073; font-size: 1.00em; }
                        input { border: 1px solid #CCCCCC; border-radius: 5px; color: #666666; display: inline-block; font-size: 1.00em;  padding: 5px; width: 100%; }
                        input[type="button"], input[type="reset"], input[type="submit"] { height: auto; width: auto; cursor: pointer; box-shadow: 0px 0px 5px #0361A8; float: right; margin-top: 10px; }
                        table.center { margin-left:auto; margin-right:auto; }
                        .error { font-family: verdana,arial; color: #D41313; font-size: 1.00em; }
                    </style>
                    <form method="post" action="adm-login.php" name="aform" target="_top">
                        <input type="hidden" name="action" value="login" />
                        <input type="hidden" name="hide" value="" />
                        <table class='center'>
                            <tr><td>Login:</td><td><input type="text" name="login" /></td></tr>
                            <tr><td>Password:</td><td><input type="password" name="password" /></td></tr>
                            <tr><td></td><td><input type="submit" value="Send" /></td></tr>
                            <tr><td colspan=2></td></tr>
                            <tr><td colspan=2>Lost your username or password? Find it <a href="https://www.authpro.com/auth/deluxe/?action=lost">here</a>!</td></tr>
                            <tr><td colspan=2></td></tr>
                        </table>
                    </form>
                </div></div></div>
    </body>
</html>