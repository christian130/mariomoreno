<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>vasPLUS Programming Blog</title>




<!-- Required header files -->
<link href="css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/file_uploads.js"></script>
<script type="text/javascript" src="js/vpb_script.js"></script>



</head>
<body>


<div id="vasPhoto_uploads_Status"></div>

<form id="vasPLUS_Programming_Blog_Form" method="post" enctype="multipart/form-data" action="tweet_image.php" autocomplete="off">
<div class="vasplusfile_adds"><input type="file" name="vasPhoto_uploads" id="vasPhoto_uploads" style="opacity:0;-moz-opacity:0;filter:alpha(opacity:0);z-index:9999;width:90px;padding:5px;cursor:default;" /></div>
</form>


<!-- Code Ends -->






</center>
</body>
</html>