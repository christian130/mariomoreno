<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
define('TUMBLR_CONSUMER_KEY', 'VCwyd0OuHth9uxTgVCidwt7EZDjPPHzBJN6pYSCoD07TPI53iD');
define('TUMBLR_CONSUMER_SECRET', 'mBfTjUng6jSPfSWlKVpEQnwX8WgflCFG8S4AUbDXP8S3AZilGx');
define('TUMBLR_CALLBACK', 'http://localhost/projects/whatsdadilly/tumblr_add.php');
?>
