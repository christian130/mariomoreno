<?php
//Replace XXX with your twitter application variables.
define('CONSUMER_KEY', 'sHQDVwHE6N0A45QlR5Q');
define('CONSUMER_SECRET', 'IxG87DcyIYiQC3QyYEXt5zmhTvm2YbRp8XGF1ZwSIs');
define('OAUTH_CALLBACK', 'http://localhost/twiteetwall/process.php');
define('IG_CONSUMER_KEY', '5fef3ae07da7486e98694e4efa67156f');
define('IG_CONSUMER_SECRET', '11f7da8075364c6ba1e04691c54a849a');
define('IG_OAUTH_CALLBACK', 'http://localhost/projects/whatsdadilly/instagram_add.php');
?>